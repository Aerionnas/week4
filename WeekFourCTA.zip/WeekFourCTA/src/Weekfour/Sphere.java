package Weekfour;

public class Sphere extends Shape {
	private double radius;

	public Sphere(double radius) {
		this.radius = radius;
	}

	public double surface_area() {
		return 4 * Math.PI * Math.pow(radius, 2);
	}

	public double volume() {
		return (4.0 / 3.0) * Math.PI * Math.pow(radius, 3);
	}

	public String toString() {
		return "This is the information for this sphere. Surface area: " + surface_area() + " Volume: " + volume();
	}

}
