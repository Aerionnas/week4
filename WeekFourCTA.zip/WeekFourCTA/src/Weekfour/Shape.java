package Weekfour;

public abstract class Shape {
	public abstract double surface_area();

	public abstract double volume();

}
