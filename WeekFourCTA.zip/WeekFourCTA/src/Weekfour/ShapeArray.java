package Weekfour;

public class ShapeArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sphere sphere = new Sphere(4.0);
		Cylinder cylinder = new Cylinder(4.0, 6.0);
		Cone cone = new Cone(5.0, 7.0);
		Shape[] shapeArr = new Shape[3];
		shapeArr[0] = sphere;
		shapeArr[1] = cylinder;
		shapeArr[2] = cone;

		for (Shape shape : shapeArr) {
			System.out.println(shape.toString());
		}
	}

}
