package Weekfour;

public class Cone extends Shape {
	private double radius;
	private double height;

	public Cone(double radius, double height) {
		this.radius = radius;
		this.height = height;
	}

	public double surface_area() {
		double slantHeight = Math.sqrt(Math.pow(radius, 2) + (Math.pow(height, 2)));
		return Math.PI * Math.pow(radius, 2) + Math.PI * radius * slantHeight;
	}

	public double volume() {
		return (1.0 / 3.0) * Math.PI * Math.pow(radius, 2) * height;
	}

	public String toString() {
		return "This is the information for this cone. Surface area: " + surface_area() + " Volume: " + volume();
	}

}
